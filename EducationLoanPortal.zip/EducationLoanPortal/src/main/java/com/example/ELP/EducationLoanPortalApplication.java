package com.example.ELP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EducationLoanPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(EducationLoanPortalApplication.class, args);
	}

}
