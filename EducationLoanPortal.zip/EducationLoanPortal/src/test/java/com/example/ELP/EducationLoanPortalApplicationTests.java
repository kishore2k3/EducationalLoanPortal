package com.example.ELP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EducationLoanPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
